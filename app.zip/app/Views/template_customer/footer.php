<script src="<?= base_url('/public/assets/marketplace/'); ?>js/jquery-3.3.1.min.js"></script>
<script src="<?= base_url('/public/assets/marketplace/'); ?>js/popper.min.js"></script>
<script src="<?= base_url('/public/assets/marketplace/'); ?>js/bootstrap.min.js"></script>
<script src="<?= base_url('/public/assets/marketplace/'); ?>js/owl.carousel.min.js"></script>
<script src="<?= base_url('/public/assets/marketplace/'); ?>js/jquery.sticky.js"></script>
<script src="<?= base_url('/public/assets/marketplace/'); ?>js/jquery.waypoints.min.js"></script>
<script src="<?= base_url('/public/assets/marketplace/'); ?>js/jquery.animateNumber.min.js"></script>
<script src="<?= base_url('/public/assets/marketplace/'); ?>js/jquery.fancybox.min.js"></script>
<script src="<?= base_url('/public/assets/marketplace/'); ?>js/jquery.easing.1.3.js"></script>
<script src="<?= base_url('/public/assets/marketplace/'); ?>js/bootstrap-datepicker.min.js"></script>
<script src="<?= base_url('/public/assets/marketplace/'); ?>js/aos.js"></script>

<script src="<?= base_url('/public/assets/marketplace/'); ?>js/main.js"></script>

</body>

</html>